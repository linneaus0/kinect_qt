import json
import os
import queue
import sys
import time
import tkinter
from datetime import datetime
from tkinter import filedialog

import cv2
from PyQt5 import QtCore, QtGui
from PyQt5.QtCore import QThread
from PyQt5.QtWidgets import QApplication, QMainWindow

from panel import Ui_MainWindow


# TODO: 1. 输入内容格式检查，特判 2. log提示完善 3. 模块化


class ControlBoard(QMainWindow, Ui_MainWindow):
    signal_to_save = QtCore.pyqtSignal()
    signal_to_stop_cam = QtCore.pyqtSignal()
    signal_to_load_default_type = QtCore.pyqtSignal(str)

    def __init__(self):
        super(ControlBoard, self).__init__()

        self.setupUi(self)

        self.writer = None
        self.sm = None
        self.cam = None
        self.q_cam_image = None
        self.cur_image = None
        self.cur_path = None
        self.q_save = None

        self.init_subthread()
        self.init_ui()

        print('Initialization complete.')

    def init_subthread(self):
        self.init_writer()
        self.init_session_manager()
        self.init_camera()

    def init_writer(self):
        self.writer = Writer()
        sys.stdout = self.writer
        sys.stderr = self.writer

    def init_session_manager(self):
        self.q_save = queue.Queue()
        self.q_replay = queue.Queue()
        self.sm = SessionManager(self.q_save, self.q_replay)

    def init_camera(self):
        self.q_cam_image = queue.Queue()
        self.cam = Camera(self.q_cam_image)

    def init_ui(self):
        self.init_path_panel()
        self.init_camera_panel()
        self.init_monitor_panel()
        self.init_log_panel()
        self.init_replay_panel()

    #########################################################################PATH SELECTION

    def init_path_panel(self):
        self.init_path_panel_slot()
        self.init_path_panel_ui()

    def init_path_panel_slot(self):
        self.pushButton_7.clicked.connect(self.select_path)
        self.lineEdit.textChanged.connect(self.sync_path)
        self.pushButton_3.clicked.connect(lambda: self.sm.launch_session(self.cur_path))

        self.sm.signal_launched.connect(self.disable_path_edit)
        self.sm.signal_end.connect(self.enable_path_edit)
        self.sm.signal_end.connect(self.init_path_panel_ui)

    def init_path_panel_ui(self):
        self.lineEdit.setText(os.getcwd())
        self.sync_path()

    def select_path(self):
        """run a tkinter dialogue to select a path"""
        tkinter.Tk().withdraw()  # prevents an empty tkinter window from appearing
        path = filedialog.askdirectory()
        self.lineEdit.setText(path)
        self.sync_path()

    def sync_path(self):
        """maintain current display path"""
        self.cur_path = self.lineEdit.text()

    def enable_path_edit(self):
        self.pushButton_7.setEnabled(True)
        self.lineEdit.setEnabled(True)

    def disable_path_edit(self):
        self.pushButton_7.setEnabled(False)
        self.lineEdit.setEnabled(False)

    #########################################################################CAMERA

    def init_camera_panel(self):
        self.init_camera_panel_ui()
        self.init_camera_panel_slot()

    def init_camera_panel_ui(self):
        self.disable_cam_elem()
        self.disable_capture()

    def init_camera_panel_slot(self):

        self.pushButton.clicked.connect(lambda: self.cam.switch(int(self.lineEdit_5.text())))  # open local camera
        self.pushButton_8.clicked.connect(lambda: self.cam.web_switch(
            self.lineEdit_2.text(),
            self.lineEdit_3.text(),
            self.lineEdit_4.text()
        ))  # connect web camera

        self.pushButton_2.clicked.connect(self.save)
        self.pushButton_6.clicked.connect(self.save)

        self.sm.signal_launched.connect(self.enable_cam_elem)
        self.sm.signal_end.connect(self.init_camera_panel_ui)

        self.cam.signal_to_start.connect(self.enable_capture)
        self.cam.signal_to_start.connect(self.block_another)
        self.cam.signal_to_end.connect(self.disable_capture)
        self.cam.signal_to_end.connect(self.unblock_both)

        self.signal_to_save.connect(self.sm.save)

    def enable_cam_elem(self):
        self.frame_6.setEnabled(True)

    def disable_cam_elem(self):
        self.frame_6.setEnabled(False)

    def block_another(self):
        if self.tabWidget.currentIndex() == 0:
            self.tab_2.setEnabled(False)
        else:
            self.tab.setEnabled(False)

    def unblock_both(self):
        self.tab.setEnabled(True)
        self.tab_2.setEnabled(True)

    def disable_capture(self):
        self.pushButton_2.setEnabled(False)
        self.pushButton_6.setEnabled(False)

    def enable_capture(self):
        self.pushButton_2.setEnabled(True)
        self.pushButton_6.setEnabled(True)

    def save(self):
        if self.cur_image is None:
            print('Nothing to save.')
        else:
            print('Saving...')
            self.q_save.put(self.cur_image)
            self.signal_to_save.emit()

    #########################################################################LOG PANEL

    def init_log_panel(self):
        self.init_log_panel_slots()
        self.init_log_panel_ui()

    def init_log_panel_slots(self):
        self.writer.signal_to_write.connect(self.write_text)

        self.sm.signal_end.connect(self.init_log_panel_ui)

    def init_log_panel_ui(self):
        self.textBrowser.clear()

    def write_text(self, text):
        """to display text on the testBrowser
        this is a must to do the display work in the main thread
        """
        cursor = self.textBrowser.textCursor()
        cursor.movePosition(QtGui.QTextCursor.End)
        cursor.insertText(text)
        self.textBrowser.setTextCursor(cursor)
        self.textBrowser.ensureCursorVisible()

    #########################################################################MONITOR PANEL

    def init_monitor_panel(self):
        self.init_monitor_panel_slot()
        self.init_monitor_panel_ui()

    def init_monitor_panel_slot(self):
        self.signal_to_stop_cam.connect(self.cam.stop)

        self.cam.signal_to_refresh.connect(self.refresh_image)
        self.cam.signal_to_end.connect(self.init_monitor_panel_ui)
        self.sm.signal_end.connect(self.init_monitor_panel_ui)

    def init_monitor_panel_ui(self):
        self.stop_cam()
        self.clear_image()

    def refresh_image(self):
        to_show = self.q_cam_image.get()

        self.label.setPixmap(QtGui.QPixmap.fromImage(to_show))
        self.label_2.setPixmap(QtGui.QPixmap.fromImage(to_show))
        self.label_3.setPixmap(QtGui.QPixmap.fromImage(to_show))

        self.cur_image = to_show

    def clear_image(self):
        self.label.clear()
        self.label_2.clear()
        self.label_3.clear()

        self.cur_image = None

    def stop_cam(self):
        self.signal_to_stop_cam.emit()

    #########################################################################replay panel

    def init_replay_panel(self):
        self.init_replay_panel_slot()
        self.init_replay_panel_ui()

    def init_replay_panel_slot(self):
        self.signal_to_load_default_type.connect(
            lambda :self.sm.load_sub_images(self.comboBox.currentText()))
        self.comboBox.activated.connect(
            lambda: self.sm.load_sub_images(self.comboBox.currentText()))
        self.pushButton_4.clicked.connect(self.sm.load_prev)
        self.pushButton_5.clicked.connect(self.sm.load_next)

        self.sm.signal_launched.connect(self.load_replay_panel)
        self.sm.signal_launched.connect(self.enable_replay_panel)
        self.sm.signal_refresh_replay.connect(self.refresh_replay)
        self.sm.signal_clear_replay.connect(self.clear_replay)
        self.sm.signal_end.connect(self.init_replay_panel_ui)

    def init_replay_panel_ui(self):
        self.clear_replay()
        self.comboBox.clear()
        self.disable_replay_panel()

    def enable_replay_panel(self):
        self.frame_8.setEnabled(True)

    def disable_replay_panel(self):
        self.frame_8.setEnabled(False)

    def load_replay_panel(self):
        self.comboBox.addItems(self.sm.types)
        self.signal_to_load_default_type.emit(self.comboBox.currentText())

    def refresh_replay(self):
        to_show = self.q_replay.get()

        self.label_8.setPixmap(QtGui.QPixmap.fromImage(to_show))

    def clear_replay(self):
        self.label_8.clear()


class Writer(QThread):
    signal_to_write = QtCore.pyqtSignal(str)

    def __init__(self):
        super(Writer, self).__init__()

    def write(self, text):
        self.signal_to_write.emit(str(text))


class SessionManager(QThread):
    signal_launched = QtCore.pyqtSignal()
    signal_refresh_replay = QtCore.pyqtSignal()
    signal_clear_replay = QtCore.pyqtSignal()
    signal_end = QtCore.pyqtSignal()

    config_file_name = 'config.json'
    auth_code = 'c21b5a87-d267-4325-acbd-de5da26a68ff'

    types = ['one', 'two', 'three', 'four']

    def __init__(self, q_save: queue.Queue, q_replay: queue.Queue, file_format='png'):
        super(SessionManager, self).__init__()

        self.q_save = q_save  # PC model
        self.q_replay = q_replay
        self.file_format = file_format

        self.session_dir = None
        self.cur_sub_images = None
        self.cur_sub_image_idx = -1

    def init_dir(self, path):
        """Initialize the folder:
        create some folders and create a json file"""
        # generate dict
        j = {'auth': self.auth_code}
        for type in self.types:
            type_dir = os.path.join(path, type)
            type_dir = type_dir.replace('\\', '/')
            os.makedirs(type_dir)
            j[type] = type_dir
        j = json.dumps(j)
        # write to json file
        with open(os.path.join(path, self.config_file_name), 'w') as f:
            f.write(j)

    def verify_json(self, file_path):
        with open(file_path, 'r') as f:
            j = json.load(f)
        return j['auth'] == self.auth_code

    def verify_path(self, path: str):
        """verify whether the selected path
        valid when and only when:
            0. not exists
            1. empty dir
            or
            2. dir is not empty and with a valid config json file
        in case 0 and 1, the dir will be initialized
        """

        # if the path is valid
        # TODO: 这里还要判断路径名是否是已存在或可创建的
        if True:
            pass
        else:
            return False

        # if dir not exists
        if not os.path.exists(path):
            # print('不存在，要新建')
            os.makedirs(path)
            self.init_dir(path)
            return True

        content = os.listdir(path)

        if len(content) == 0:  # if empty
            # print('存在，为空')
            self.init_dir(path)
            return True
        elif self.config_file_name in content:  # if not, check json
            # print('存在config文件')
            file_path = os.path.join(path, self.config_file_name)
            file_path = file_path.replace('\\', '/')
            return self.verify_json(file_path)

        # print('不为空，但是config校验不通过')
        return False

    def launch_session(self, path):
        """首先检验地址，
        若成功：发出信号，信号用于：解除按钮禁用; 禁止编辑地址;加载已有数据"""

        if not self.session_dir is None:
            self.end_session()
            return

        # verify the path
        if self.verify_path(path):  # verify
            print('Path is valid. Loading...')
        else:
            print('Path is not valid. Launch failed.')
            return

        print('Launch success.')
        self.session_dir = path
        self.signal_launched.emit()

    def end_session(self):
        """发出信号，信号用于：
        按钮禁用，清空画面（将前端恢复到session开始前的状态）"""
        self.session_dir = None
        self.cur_sub_images = None
        self.cur_sub_image_idx = -1
        self.signal_end.emit()

    def save(self, sub=None):
        if sub is None:
            sub = self.types[0]
        time_now = datetime.now().strftime(f'%Y-%m-%d-%H-%M-%S-%f')
        file_path = os.path.join(self.session_dir, sub, time_now) + '.' + self.file_format
        file_path = file_path.replace('\\', '/')

        to_save: QtGui.QImage = self.q_save.get()
        success = to_save.save(file_path)
        if success:
            print(f'Saved to "{file_path}" .')
        else:
            print('Failed to save.')

    def load_sub_images(self, sub):

        sub_dir = os.path.join(self.session_dir, sub)
        sub_image_path_list = [
            os.path.join(sub_dir, _path).replace('\\', '/')
            for _path in os.listdir(sub_dir)]

        sub_images = []
        for image_path in sub_image_path_list:
            image = cv2.imread(image_path)
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)  # 视频色彩转换回RGB，这样才是现实的颜色
            image = QtGui.QImage(image.data, image.shape[1], image.shape[0],
                                 QtGui.QImage.Format_RGB888)  # 把读取到的视频数据变成QImage形式
            sub_images.append(image)
        self.cur_sub_images = sub_images

        if len(sub_images) == 0:
            self.cur_sub_image_idx = -1
            self.signal_clear_replay.emit()
        else:
            self.cur_sub_image_idx = 0
            self.q_replay.put(self.cur_sub_images[0])
            self.signal_refresh_replay.emit()

    def load_next(self):
        if self.cur_sub_image_idx < len(self.cur_sub_images) - 1:
            self.cur_sub_image_idx += 1
            image = self.cur_sub_images[self.cur_sub_image_idx]
            self.q_replay.put(image)
            self.signal_refresh_replay.emit()

    def load_prev(self):
        if self.cur_sub_image_idx > 0:
            self.cur_sub_image_idx -= 1
            image = self.cur_sub_images[self.cur_sub_image_idx]
            self.q_replay.put(image)
            self.signal_refresh_replay.emit()


class Camera(QThread):
    signal_to_start = QtCore.pyqtSignal()
    signal_to_refresh = QtCore.pyqtSignal()
    signal_to_end = QtCore.pyqtSignal()

    def __init__(self, q: queue.Queue, period=30):
        super(Camera, self).__init__()

        self.cap = cv2.VideoCapture()
        self.timer_camera = QtCore.QTimer()  # to specify frame rate

        self.period = period  # 帧周期

        self.q = q  # PC model

        self.timer_camera.timeout.connect(self.capture)

    @property
    def on(self):
        return self.timer_camera.isActive()

    def switch(self, url=None):
        if self.on:  # 若定时器未启动
            self.stop()
            return

        print('Connecting ...')
        flag = self.cap.open(url)  # 参数是0，表示打开笔记本的内置摄像头，参数是视频文件路径则打开视频

        if not flag:  # flag表示open()成不成功
            print('Failed.')
        else:
            print('Success.')
            self.signal_to_start.emit()
            self.timer_camera.start(self.period)  # 定时器开始计时30ms，结果是每过30ms从摄像头中取一帧显示

    def stop(self):
        if self.on:
            self.timer_camera.stop()  # 关闭定时器
            self.cap.release()  # 释放视频流
            self.signal_to_end.emit()
            print('Closed.')

    def web_switch(self, address, username, password):
        url = 'rtsp://' + username + ':' + password + '@' + address
        self.switch(url)

    def capture(self):
        # capture a image
        flag, image = self.cap.read()  # 从视频流中读取
        # show = cv2.resize(self.image, (width, height))  # 把读到的帧的大小重新设置为 640x480
        to_show = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)  # 视频色彩转换回RGB，这样才是现实的颜色
        to_show = QtGui.QImage(to_show.data, to_show.shape[1], to_show.shape[0],
                               QtGui.QImage.Format_RGB888)  # 把读取到的视频数据变成QImage形式

        self.q.put(to_show)

        self.signal_to_refresh.emit()


def test_fn():
    for i in range(5):
        print(i)
        time.sleep(0.2)
    print('End')


if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = ControlBoard()
    win.show()
    sys.exit(app.exec_())
