import matplotlib.pyplot as plt

import cv2

cap = cv2.VideoCapture()

url = 'rtsp://admin:My-camera0806@192.168.1.102:554/Streaming/Channels/101'

print('Connecting ...')
flag = cap.open(url)  # 参数是0，表示打开笔记本的内置摄像头，参数是视频文件路径则打开视频

if not flag:  # flag表示open()成不成功
    print('Failed.')
else:
    print('Success.')

flag, image = cap.read()  # 从视频流中读取
# show = cv2.resize(self.image, (width, height))  # 把读到的帧的大小重新设置为 640x480
to_show = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)  # 视频色彩转换回RGB，这样才是现实的颜色

plt.imshow(to_show)
plt.show()





