from PyQt5 import QtCore, QtGui
import sys
from PyQt5.QtCore import QEventLoop, QTimer, QThread
from PyQt5.QtWidgets import QApplication, QMainWindow
from threading import Thread
 
from test import Ui_MainWindow

import time
 
 
class ControlBoard(QMainWindow, Ui_MainWindow):

    def __init__(self):
        super(ControlBoard, self).__init__()

        # some initiations
        self.setupUi(self)

        # rebroadcast to the textBrowser
        self.writer = Writer()
        self.writer.signal_to_write.connect(self.writeText)
        sys.stdout = self.writer
        sys.stderr = self.writer

        # bond the signals and slots
        self.pushButton.clicked.connect(self.bClicked)

    def writeText(self, text):
        """to display text on the testBrowser
        this is a must to do the display work in the main thread
        """
        cursor = self.textBrowser.textCursor()
        cursor.movePosition(QtGui.QTextCursor.End)
        cursor.insertText(text)
        self.textBrowser.setTextCursor(cursor)
        self.textBrowser.ensureCursorVisible()

    def bClicked(self):
        t = Thread(target=test_fn)#目标函数
        t.start()#启动线程


class Writer(QThread):
    signal_to_write = QtCore.pyqtSignal(str)

    def __init__(self):
        super(Writer, self).__init__()

    def write(self, text):
        self.signal_to_write.emit(str(text))


def test_fn():
    for i in range(5):
        print(i)
        time.sleep(0.2)
    print('End')


if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = ControlBoard()
    win.show()
    sys.exit(app.exec_())